import math as math
import numpy as np
Avalues = [6, 5, 5, 10, 8, 14, 10, 4, 8, 5, 6]
Bvalues = [9, 8, 11, 12, 11, 13,12, 9, 9, 7, 9]


def calculateMean(inputList):
    sumnum = 0
    count = 0
    for value in (inputList):
        sumnum = sumnum + value
    returning = sumnum/len(inputList)
    return(returning)

def calculateVariance(mean, mylist):
    #this code clones list so I don't break it.
    count = 0
    templist = []
    while count < len(mylist):
        templist.append(mylist[count])
        count = count +1
    count = 0
    while count < len(templist):
        
        tempvalue = templist[count]-mean
        tempvalue = tempvalue * tempvalue
        templist[count] = tempvalue
        count = count +1
    returning = calculateMean(templist)
    return(returning)

def calculateStanDev(varience):
    square_root = math.sqrt(varience)
    return square_root

def calculateCovariance(valuesA, valuesB, meanA, meanB):
    listlen = len(valuesA)
    mathchunk = 0
    loopcount = 0
    while loopcount < listlen:
        minusMuA = valuesA[loopcount] - meanA
        minusMuB = valuesB[loopcount] - meanB
        thingtosum = minusMuA*minusMuB
        mathchunk = mathchunk + thingtosum
        loopcount = loopcount + 1
        
    goldnum = mathchunk / listlen 
    return goldnum
       
        
    #return mathchunk

#this one works, but only on certain data sets. no idea why. very mad. had to replace
def oldcalculateCorrelation(setA, setB):
    meanA = calculateMean(Avalues)
    meanB = calculateMean(Bvalues)
    varA = calculateVariance(meanA, setA)
    varB = calculateVariance(meanB, setB)
    varAB = varA * varB
    denominator = math.sqrt(varAB)
    covariance = calculateCovariance(Avalues, Bvalues, meanA, meanB)
    corrAns = covariance / denominator
    return corrAns
    
def calculateCorrelation(setA, setB):
    returning = np.corrcoef(setA, setB)[0,1]
    return returning

corr = calculateCorrelation(Avalues, Bvalues)
