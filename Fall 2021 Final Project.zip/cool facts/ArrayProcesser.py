import math as math
import numpy as np
import MathSolver as MS
class XY:
    
    def __init__(self, listA, listB, yearA, yearB):
        self.listA = listA
        self.listB = listB
        self.yearA = yearA
        self.yearB = yearB
        self.mathArray = []
        
        self.wholeHalves = []
        self.dataHalf = self.transpose(self.trim(self.read(self.listA)))
        self.secondHalf = self.transpose(self.trim(self.read(self.listB)))
        self.CloneA = []
        self.CloneB = []
        for value in self.dataHalf.tolist()[1]:
            self.CloneA.append(float(value))
        for value in self.secondHalf.tolist()[1]:
            self.CloneB.append(float(value))   

        
     

        self.mathArray = self.mathSolve(self.CloneA, self.CloneB)
        
        
        

        self.meanA = self.mathArray[0]
        self.meanB = self.mathArray[1]
        self.varianceA = self.mathArray[2]
        self.varianceB = self.mathArray[3]
        self.StanDevA = self.mathArray[4]
        self.StanDevB = self.mathArray[5]
        self.covariance = self.mathArray[6]
        self.correlation = self.mathArray[7]

        
        
     
        
        
    def read(self, inputName):
        fileName = "sub/" + inputName + ".txt"
        with open(fileName, 'r') as file:
            DDarray = []
            #processes a single line, splitting and stripping,adds to array moves to next.
            for line in file:
                line = line.replace("\n", "")
                line = line.split(", ")
                DDarray.append(line)    
        return(DDarray)
    
    def trim(self, inputArray):
       
        midArray = []
        for i in inputArray:
            if int(i[0]) >= self.yearA and int(i[0]) <= self.yearB:
                midArray.append(i)
        return(midArray)
                      
    
    def transpose(self, transArray):
        Transvar = transArray
        arr = np.array(Transvar)
        arr = arr.T
        return(arr)
        
        #print("goal")
        #self.corellation = MS.correlation(self.end)
        #self.listA[0]
        #MS.run(self.listA[0],self.listA[1] )
    def mathSolve(self, YvaluesA, YvaluesB):
        returnMeanA = MS.calculateMean(YvaluesA)
        returnMeanB = MS.calculateMean(YvaluesB)
        returnVarianceA = MS.calculateVariance(returnMeanA, YvaluesA)
        returnVarianceB = MS.calculateVariance(returnMeanB, YvaluesB)
        returnStanDevA = MS.calculateStanDev(returnVarianceA)
        returnStanDevB = MS.calculateStanDev(returnVarianceB)
        returnCovariance = MS.calculateCovariance(YvaluesA, YvaluesB, returnMeanA, returnMeanB)
        returnCorrelation = MS.calculateCorrelation(YvaluesA, YvaluesB)
       
        return returnMeanA, returnMeanB, returnVarianceA, returnVarianceB, returnStanDevA, returnStanDevB, returnCovariance, returnCorrelation
        
                
