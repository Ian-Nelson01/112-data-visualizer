import random as randy
import ArrayProcesser as ap
import pandas as pd
import matplotlib.pyplot as plot

#branching if else requests 2 ints to work within, forces ints to be in 2 year format
def yeargrab():
    yeartemp = 0
    while yeartemp == 0:
        rangecheck = input("What range of years would you like to look at? ex. 1990-2019  |  ")
        rangecheck = rangecheck.split("-")
        
        if len(rangecheck) == 2:
            
            #Checks if input is a number, ruling out letters and characters. unfortunatly this means no decimals :(
            if rangecheck[0].isnumeric() == True and rangecheck[1].isnumeric() == True:
                startD = int(rangecheck[0])
                endD = int(rangecheck[1])
                #this line is going monke under mysterious circumstances
                if startD >= 1990 and startD <= 2018:
    
                    if endD >= 1991 and endD <= 2019:
                        if startD < endD:
                            break   
                            yeartemp = 9001
                        else:
                            print("Start date cannot be after end date.")
                    else:
                        print("End date should be between 1991 and 2019")
                else:
                    print("Start date should be between 1990 and 2018")
            #Adds myInput to list
            else:
                print("Please input integer numbers for years (and not words)")
        print("Try writing a range of 2 dates using a dash in the middle like 2001-2005, or 1994-2014")
    return startD, endD

#branching if else requests 2 ints to work within, forces ints to be in 1-30 format
def randgrab():
    yeartemp = 0
    while yeartemp == 0:
        rangecheck = input("What range of random numbers would you like to work with? ex. 0-30  |  ")
        rangecheck = rangecheck.split("-")
        
        if len(rangecheck) == 2:
            
            #Checks if input is a number, ruling out letters and characters. unfortunatly this means no decimals :(
            if rangecheck[0].isnumeric() == True and rangecheck[1].isnumeric() == True:
                startD = int(rangecheck[0])
                endD = int(rangecheck[1])
                #this line is going monke under mysterious circumstances
                if startD >= 0 and startD <= 30:
    
                    if endD >= 0 and endD <= 30:
                        if startD <= endD:
                            break   
                            yeartemp = 9001
                        else:
                            print("First number cannot be after second number.")
                    else:
                        print("Second number must be 0-30.")
                else:
                    print("First number must be 0-30.")
            #Adds myInput to list
            else:
                print("Please input integer numbers for values (and not words)")
        print("Try writing a range of 2 numbers using a dash in the middle like 0-5, or 24-30")
    return startD, endD

def numGrab():
    yeartemp = 0
    while yeartemp == 0:
        rangecheck = input("What range of random numbers would you like to work with? ex. 0-30  |  ")
        print("over 10? " + rangecheck)
        
        if len(rangecheck) < 3:
            
            #Checks if input is a number, ruling out letters and characters. unfortunatly this means no decimals :(
            periodcheck = rangecheck.replace(".", "")
            if periodcheck.isnumeric() == True:
                startD = int(rangecheck)
                #this line is going monke under mysterious circumstances
                if startD >= 0 and startD <= 30:
                    break   
                    yeartemp = 9001
                else:
                    print("Only 0-30 are submitable")
            else:
                print("please input an integer or decimal number")

            #Adds myInput to list
        print("Any number between 0 and 30 will do.")
    return startD


#this is up here so random files don't get re-written
randoFILES = []
#makes randomized files with x values yeargrab, and y values randgrab
def randomFile(sYear, eYear,filenames = randoFILES, no = len(randoFILES)+1):
    

    cont = 0
    doneOnce = ""
    while cont != -1:
            
        
        answer = input("Would you like to make a" + doneOnce + " random file?  |  ")
        
        if answer.lower() == "no":
            doneOnce = "nother"
            cont = -1
            break
        if answer.lower() == "yes":
            doneOnce = "nother"
            filenames.append("Random Data No." + str(no))
            with open("sub/Random Data No." + str(no) +".txt", 'w') as file:
                var = sYear
                starter, ender = randgrab()
                
                while var <= eYear:
                    valueB = str(randy.randint(starter, ender))
                    valueA = str(var)
                    valueC = valueA + ", " + valueB 
                    if var != eYear:  
                        file.write(valueC + "\n")
                    else:
                        file.write(valueC)
                    var = var+1      
            no = no + 1
        else:
            print("please answer yes or no")
    return filenames
#makes custom files with x values yeargrab, and y values randgrab
userFILES = []
def userFile(sYear, eYear, listnames = userFILES):

    no = 1
    doneOnce = ""
    while no != -1:
            
        
        answer = input("Would you like to make a" + doneOnce + " custom file?  |  ")
        
        if answer.lower() == "no":
            doneOnce = "nother"
            no = -1
            break
        if answer.lower() == "yes":
            doneOnce = "nother"
            coolname = input("Enter a name for your custom data set  |  ")
            listnames.append(coolname)
            with open("sub/" +coolname +".txt", 'w') as file:
                var = sYear

                
                while var <= eYear:
                    valueB = str(numGrab())
                    valueA = str(var)
                    valueC = valueA + ", " + valueB 
                    if var != eYear:  
                        file.write(valueC + "\n")
                    else:
                        file.write(valueC)
                    var = var+1      
            print("Custom file generated!")
            no = no + 1
        else:
            print("please answer yes or no")
    return listnames

def listAll():
    allFiles = ["", "Age of Miss America", "American Per Capita Turkey Consumption in Pounds", "Super Bowl Point Difference Between Winner and Loser", "Seattle annual precipitation (in inches)", "Domestic Yearly Box Office Ticket Sales for Top Movie (per 100 million US dollars)", "US Average Life Expectancy (in years)", "US Average Number of Children per Family"]
    return allFiles

def picktwo(ranFiles, useFiles):
    returnA = ""
    returnB = ""
    stillHappening = True
    while stillHappening == True: 
        totalList = listAll()
        for i in ranFiles:
            totalList.append(i)
        for i in useFiles:
            totalList.append(i)
        for i in totalList:
            print(i)    
        print("")
        print("Choose your first dataset from one of the the above")
        myInputA = input("Input name of first dataset  |  ")
        inventory = False
        for i in totalList:
            if myInputA == i:
                inventory = True
        if inventory == True:
            returnA = myInputA
            stillHappening = False
        else:
            print("File not found. Try again")
    
    stillHappening = True
    while stillHappening == True: 
        for i in totalList:
            print(i)    
        print("")
        print("Choose your second dataset from one of the the above")
        myInputB = input("Input name of second dataset  |  ")
        inventory = False
        for i in totalList:
            if myInputB == i:
                inventory = True
        if inventory == True:
            returnB = myInputB
            stillHappening = False
        else:
            print("File not found. Try again") 
    return returnA, returnB
objList = []
objNameList = []         
def objMaker(pickA, pickB, startDate, endDate):

    ap.XY(pickA, pickB, startDate, endDate)
    
    return ap.XY(pickA, pickB, startDate, endDate)
       
def objLibrary(objList, objNameList):

    obtChosen = False
    while obtChosen == False:
        print("Which Graph would you like to see?")
        for i in objNameList:

            print(i)
        inputSTR = input("")
        chosenOne = -1
        #CHECK FOR DUPES SOMEWHERE like rand?
        grandCount = 0
        while grandCount < len(objNameList):
            
            if objNameList[grandCount] == inputSTR:
                chosenOne = grandCount
                obtChosen = True
                grandCount = grandCount + 1
            else: 
                print("Be mindful to spell your choice correctly")
                break
                
    return objList[chosenOne], objList, objNameList
        
                
            
            
            

def outputHall(objBoy):
    
    myindex = []
    altSDate = startDate
    altEDate = endDate + 1
    while altSDate != altEDate:
        myindex.append(altSDate)
        altSDate = altSDate + 1






    df = pd.DataFrame({
       objBoy.listA : objBoy.CloneA,
       objBoy.listB : objBoy.CloneB
       }, index= myindex)


    lines = df.plot.line()
                 


     

    # Draw a line chart
    titlecard = "Correlation between " + objBoy.listA + ", and " + objBoy.listB

    df.plot.line(title=titlecard, rot = 20)

    plot.show(block=True)




    print(objBoy.listA)
    print(objBoy.CloneA)
    print("Mean : " + str(objBoy.meanA))
    print("Variance : " + str(objBoy.varianceA))
    print("Standard Deviation : " + str(objBoy.StanDevA))
    print("")
    print(objBoy.listB)
    print(objBoy.CloneB)
    print("Mean : " + str(objBoy.meanB))
    print("Variance : " + str(objBoy.varianceB))
    print("Standard Deviation : " + str(objBoy.StanDevB))
    print("")
    print("Graph Covariance : " + str(objBoy.covariance))
    
    percentage = 100 * objBoy.correlation
    if percentage > 100:
        percentage = 100
    if percentage < -100:
        percentage = -100
    
    
    print("Graph Correlation : %" + str(percentage))


def epilogue(yearNoA, yearNoB, randoFLS, userFLS, obj, objName) :
    epilogueRun = True
    allrfiles = randoFLS
    allufiles = userFLS
    objList = []
    objNameList = []
    objList.append(obj)
    objNameList.append(objName)
    while epilogueRun == True:
        print("Would you like to: ")
        print("A: Make more random files?")
        print("B: Make more custom files?")
        print("C: Make another Correlation?")
        print("D: Show a previous Correlation?")
        print("E: Exit?")
        print("Print letter corresponding to desired choice")
        choice = input("")
        choice = choice.lower()
        
        if choice == "a":
            allrfiles = randomFile(yearNoA, yearNoB, allrfiles)
        elif choice == "b":
            allufiles = userFile(yearNoA, yearNoB, allufiles)
            
        elif choice == "c":
            pickA, pickB = picktwo(allrfiles, allufiles)

            currentOBJ = objMaker(pickA, pickB, startDate, endDate)

            outputHall(currentOBJ)
            objList.append(currentOBJ)
            objApp = "Correlation between " + pickA + ", and " + pickB
            objNameList.append(objApp)
        elif choice == "d":
            returned = objLibrary(objList, objNameList)
            currentOBJ = returned[0]
            objList.append(returned[1])
            objNameList.append(returned[2])
            outputHall(currentOBJ)
            
            
        elif choice == "e":
            epilogueRun = False 
            


       
startDate, endDate = yeargrab() #startDate, endDate = 1999, 2009
print("Lets analyse data between " + str(startDate) + " and " + str(endDate) + "!")
#start loop here for restarting run
allrfiles = randomFile(startDate, endDate)#randomFile(startDate, endDate) check randgrab
allufiles = userFile(startDate, endDate)
print("")
print("")
print("Lets begin.")

pickA, pickB = picktwo(allrfiles, allufiles)

currentOBJ = objMaker(pickA, pickB, startDate, endDate)


outputHall(currentOBJ)

#make more files?
#make more graphs?
#show a previous graph?
objApp = "Correlation between " + pickA + ", and " + pickB
epilogue(startDate, endDate, allrfiles, allufiles, currentOBJ, objApp)







